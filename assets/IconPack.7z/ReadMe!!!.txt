Hello game developer! 

THANK YOU for your purchase this icon pack!


This is an started icon pack and there are many updates ahead. The art style is semi-inspired by Heroies of Might and Magic. 
It means a lot to me that it might be used in a game, like it's all grown up!

If you use this icon pack in your game, give me a shoutout if you can at @iknowkingrabbit, so we can
follow along on your development journey! ^^ 

First off, you can find all the PNG files.

- There are two options for each icon: Original and Outline.
- AAP64 palette used
- In the EquipmentSet folder you can find ready-made armor sets.

------------------------------

The license for the material in this zip file is as follows.
Here's the important bits:

1. You may not host the contents of this zip file in whole or in part
   on any publicly avaliable server, unless as part of a game or
   similar product.

2. If you use this material in a game or other product, please give
   attribution to Aleksandr Makarov in the credits.

3. You are granted the right to modify the artwork to suit your Product.  
   Remix, transform, and build upon the material for any purpose, even commercially.  

4. That's it! Use in any for profit / not for profit product, and give
   me a shoutout at @IknowKingRabbit or Aleksandr Makarov if you can.

   Thanks!


-------------------------------

If you have any questions, get in touch with me!
-Aleksandr 

Consider supporting me if you haven't already, and get access to ALL the tilesets!
Patreon: www.patreon.com/iknowkingrabbit

Twitter: @IKnowKingRabbit