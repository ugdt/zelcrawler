Hello game developer! 

THANK YOU for downloading this tileset.
This is my biggest and most comprehensive tileset yet. My pack is a very simple, map set for a fantasy setting. The art style is semi-inspired by Heroies of Might and Magic 1. 
It means a lot to me that it might be used in a game, like it's all grown up!

If you use this tileset in your game, give me a shoutout if you can at @iknowkingrabbit, so we can
follow along on your development journey! ^^ 

First off, you can find all the PNG files you need to build your world map in the "pieces" folder.

- In CompilationTilesets, you can find all tilesets from all biomes.
- In folder "Name"+biome, you can find all tileset related to this name. 
- In Animated folder, you can find all tiles that have animation.

All of the PNGs are composed of 16x16 tiles, and are designed to fit on a 16x16 tile grid.


------------------------------

The license for the material in this zip file is as follows.
Here's the important bits:

1. You may not host the contents of this zip file in whole or in part
   on any publicly avaliable server, unless as part of a game or
   similar product.

2. If you use this material in a game or other product, please give
   attribution to Aleksandr Makarov in the credits.

3. You are granted the right to modify the artwork to suit your Product.  
   Remix, transform, and build upon the material for any purpose, even commercially.  

4. That's it! Use in any for profit / not for profit product, and give
   me a shoutout at @IknowKingRabbit or Aleksandr Makarov if you can.

   Thanks!


-------------------------------

If you have any questions, get in touch with me!
-Aleksandr 

Consider supporting me if you haven't already, and get access to ALL the tilesets!
Patreon: www.patreon.com/iknowkingrabbit

Twitter: @IKnowKingRabbit
